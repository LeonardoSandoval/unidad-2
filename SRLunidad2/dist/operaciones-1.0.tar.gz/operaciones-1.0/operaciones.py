def volumen(a: int, b: int, c: int) -> int:
    v = a * b * c
    return v


def area(a: int, b: int, c: int) -> int:
    a = 2(a*b+a*c+b*c)
    return a
