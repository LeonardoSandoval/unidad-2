from setuptools import setup

setup(
    name='operaciones',
    version='1.0',
    description='calcula el area y volumen de un Ortoedro',
    author='Emiliano Aguilar Cerna',
    author_email='Emilianoaguilarcerna@gmail.com',
    url='trello.com/pa',
    py_modules=['operaciones'],
)
