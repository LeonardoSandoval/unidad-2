def Densi(m: float, v: float) -> float:
    d = m/v
    return d


def Area(l: float) -> float:
    a = l*l
    return a
