from setuptools import setup

setup(
    name='formulas',
    version='1.0',
    description='obtiene la densidad de un material',
    author='Leonardo Sandoval',
    author_email='sandovalleo@gmail.com',
    url='trello.com/pa',
    py_modules=['formulas'],
)
