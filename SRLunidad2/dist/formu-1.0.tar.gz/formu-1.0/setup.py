from setuptools import setup

setup(
    name='formu',
    version='1.0',
    description='obtiene la densidad de un material',
    author='Leonardo Sandoval',
    author_email='sandovalleo@gmail.com',
    url='trello.com/pa',
    py_modules=['formu'],
)
